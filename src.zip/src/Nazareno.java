
public class Nazareno {

	
	//atributos
	
	private String nombre;
	private int edad;
	private int numeroCaramelos;
	private boolean reparteCera;
	
	 
	 //getters
	 
	 public String getnombre() 
	 {
		return this.nombre;
	 }
	 
	 public int getedad() 
	 {
		return this.edad;
	 }
	
	 public int getnumeroCaramelos() 
	 {
		return this.numeroCaramelos;
	 }
	 
	 public boolean getreparteCera() 
	 {
		return this.reparteCera;
	 }
	 
	 //setters
	 
	 public void setNombre(String nombre) 
	 {
			this.nombre = nombre;
		}

		public void setEdad(int edad) 
		{
			this.edad = edad;
		}

		public void setNumeroCaramelos(int numeroCaramelos) 
		{
			this.numeroCaramelos = numeroCaramelos;
		}

		public void setReparteCera(boolean reparteCera) 
		{
			this.reparteCera = reparteCera;
		}

	//toString
		
		public String toString() {
			return "Nazareno [nombre=" + nombre + 
					", edad=" + edad + 
					", numeroCaramelos=" + numeroCaramelos + 
					", reparteCera=" + reparteCera + 
					"]";
		} 
}
