import java.util.ArrayList;

public class Hermandad {
	
	
	private String Nombre;
	private String diaSalida;
	private String Paso;

	//array
		private ArrayList<Nazareno> listaNazarenos;
		
	//getter
	public String getNombre() 
	{
		return Nombre;
	}

	public String getDiaSalida() 
	{
		return diaSalida;
	}

	public String getPaso() 
	{
		return Paso;
	}

	//setter
	
	public void setNombre(String nombre) 
	{
		this.Nombre = nombre;
	}

	public void setDiaSalida(String diaSalida) 
	{
		this.diaSalida = diaSalida;
	}

	public void setPaso(String paso) 
	{
		this.Paso = paso;
	}

	//toString
	
	public String toString() {
		return "Hermandad [Nombre=" + Nombre + 
				", diaSalida=" + diaSalida + 
				", Paso=" + Paso + 
				"]";
	}
	
	//constructor
	
	public Hermandad () 
	{
		listaNazarenos=new ArrayList<>();
	}
	
	//añade un nazareno a la lista
	
		public void anadirNazareno(Nazareno n)
		{
			listaNazarenos.add(n);
		}
	
		
	//eliminar Nazareno por nombre
		
		public void eliminarNazarenoPorNombre(String nombre) 
		{
			if(listaNazarenos.isEmpty()) 
			{
				System.out.println("No hay nazarenos");
			}
			
			else
			{
				for (Nazareno temp : listaNazarenos ) 
				{
					if(temp.getnombre().equals(Nombre))
					{
						listaNazarenos.remove(temp);
						break;
					}
				}
				
			}
				
		
			
	
		}	
	//muestra todos los nazarenos
		
		public void listarNazareno() 
		{
			if(listaNazarenos.isEmpty()) 
			{
				System.out.println("No hay nazarenos");
			}
			
			else
			{
				for (Nazareno temp : listaNazarenos ) 
				{
					System.out.println(temp);
				}
				
			}
	
		}
		
		//muestra los nazarenos por nombre
		
		public void listarNazarenos() 
		{
			if(listaNazarenos.isEmpty()) 
			{
				System.out.println("No hay nazarenos");
			}
			
			else
			{
				for (Nazareno temp : listaNazarenos ) 
				{
					if(temp.getnombre().equals(Nombre))
					{
						System.out.println(temp);
					}
				}
				
			}
	
		}
		
	//muestra los nazarenos que reparten cera
		
		public void obtenerNazarenosQueRepartenCera() 
		{
			if(listaNazarenos.isEmpty()) 
			{
				System.out.println("No hay nazarenos");
			}
			
			else
			{
				for (Nazareno temp : listaNazarenos ) 
				{
					if(temp.getreparteCera())
					{
						System.out.println(temp);
					}
				}
				
			}
	
		}
		
		//muestra los nazarenos menores de 18 años
		
				public void obtenerNazarenosMenoresDeEdad() 
				{
					if(listaNazarenos.isEmpty()) 
					{
						System.out.println("No hay nazarenos");
					}
					
					else
					{
						for (Nazareno temp : listaNazarenos ) 
						{
							if(temp.getedad()<18)
							{
								System.out.println(temp);
							}
						}
						
					}
			
				}
				
				//devuelve el numero total de nazarenos
				public void contarNazarenos()
				{
					if(listaNazarenos.isEmpty()) 
					{
						System.out.println("No hay nazarenos");
					}
					
					else
					{
						for (Nazareno temp : listaNazarenos ) 
						{
							System.out.println(temp);
						}
						
					}
			
				}

				
				
		
		
}
